/* global QUnit */

sap.ui.require(["ipa/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
