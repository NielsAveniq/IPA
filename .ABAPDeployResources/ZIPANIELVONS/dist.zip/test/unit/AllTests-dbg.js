sap.ui.define([
	"ipa/test/unit/controller/View.controller"
], function () {
	"use strict";
});
